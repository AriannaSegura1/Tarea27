﻿# monitor_servicios.ps1
try {
    # Obtener información de los servicios del sistema
    $servicios = Get-Service | Select-Object Name, DisplayName, Status, StartType

    # Exportar a un archivo CSV
    $rutaCSV = "C:\Users\galle\OneDrive\Escritorio\servicios.csv"
    $servicios | Export-Csv -Path $rutaCSV -NoTypeInformation

    Write-Host "La información de los servicios se ha exportado correctamente a $rutaCSV"
} catch {
    Write-Error "Ocurrió un error al obtener o exportar la información de los servicios: $_"
    exit 1
}
